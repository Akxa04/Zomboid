Backup time: 2023-04-07 at 23:44:47 CEST
ServerName: PEPI Boiz
Current server version:41.78
Current world version:195
World version in this backup is:World isn't exist